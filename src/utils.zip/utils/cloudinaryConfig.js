// src/utils/cloudinaryConfig.js
export const cloudName = "drxzroofv";
export const uploadPreset = "unsigned_preset";
export const cloudinaryUploadUrl = `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`;
export const apiKey = "845319998196363";
export const apiSecret = "9suqfzbi9ffs6vqjTOfqliQFxAc";
